package dshukla.fizzBuzzSolution;

public class Solution {

	public static void main(String[] args) {

		FizzBuzzValidator f = new FizzBuzzValidator();
		boolean isValid = f.isFileValid(args); 
		f.outputTheResult(isValid);
		
	}

}
