package dshukla.fizzBuzzSolution;

public class InvalidJSONSyntaxException {

}
