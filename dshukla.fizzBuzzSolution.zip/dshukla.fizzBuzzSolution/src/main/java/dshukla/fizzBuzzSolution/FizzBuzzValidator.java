package dshukla.fizzBuzzSolution;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class FizzBuzzValidator {

	//object deals with input and out related task
	public static FileInputOutputHandler ioHandler;

	/**
	 * 		Function to check FIZZZBUZZ value for an int i
	 * */
	private Object fizzBuzzValue(int i) {
		boolean dividedBy3 = i%3 ==0;
		boolean dividedBy5 = i%5 ==0;
		if(dividedBy3 && dividedBy5)
			return "FIZZBUZZ";
		if(dividedBy3)
			return "FIZZ";
		if(dividedBy5)
			return "BUZZ";
		return i;
	}
	/**
	 * 
	 * funtion exposed to client to print output 
	 * @param isValid
	 */
	public void outputTheResult(boolean isValid) {
		ioHandler.writeResultObj(isValid);
	}
	/**
	 * 
	 * funtion exposed to client to validate any file 
	 * @param isValid
	 */
	public boolean isFileValid(String[] args) {
		// object deals with input and out related task
		ioHandler = new FileInputOutputHandler();
				
		JSONObject jsonObject = ioHandler.readJSONFile(args);
		return validateJSONFile(jsonObject);
	}
	
	/**
	 *  Testable code snippet -Using automated generated tests
	 * */
	public boolean validateJSONFile(JSONObject jsonObject) {
		boolean isValid = validateJSONSyntax(jsonObject);
		return isValid && validateJSONStructure(jsonObject);
	}
	
	private boolean validateJSONSyntax(JSONObject object) {
		if(!object.containsKey("lines"))
			return false;
		if(!(object.get("lines") instanceof JSONArray))
			return false;
		return true;
	}
	private boolean validateJSONStructure(JSONObject object) {
		JSONArray array = (JSONArray) object.get("lines");
		for (int i = 0; i < array.size(); i++) {
			if(!array.get(i).toString().equals(fizzBuzzValue(i+1).toString()))
				return false;			
		}
		return true;
	}
}
