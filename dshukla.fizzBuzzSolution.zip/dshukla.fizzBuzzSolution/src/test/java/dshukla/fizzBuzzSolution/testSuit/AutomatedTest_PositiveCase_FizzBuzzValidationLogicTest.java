package dshukla.fizzBuzzSolution.testSuit;

import static org.junit.Assert.*;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;

import dshukla.fizzBuzzSolution.FizzBuzzValidator;
import dshukla.fizzBuzzSolution.testSuit.automationTestsUtils.FizzBuzzJSON_Test;

public class AutomatedTest_PositiveCase_FizzBuzzValidationLogicTest {

	FizzBuzzValidator validator; 
	
	@Before
	public void init(){
		validator = new FizzBuzzValidator();
	}
	
	/**
	 * 		POSITIVE cases create by utility function FizzBuzzJSON_Test.createFizzBuzzJSON__valid
	 * **/
	/**
	 * 	Testing for JSON 1 to 50 
	 * */
	@Test
	public void test0_50Range_valid() {
		int endRange = (int)(50 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__valid(endRange);
		assertEquals(true, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 100 
	 * */
	@Test
	public void test0_100Range_valid() {
		int endRange = (int)(100 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__valid(endRange);
		assertEquals(true, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 200 
	 * */
	@Test
	public void test0_200Range_valid() {
		int endRange = (int)(200 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__valid(endRange);
		assertEquals(true, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 300 
	 * */
	@Test
	public void test0_300Range_valid() {
		int endRange = (int)(300 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__valid(endRange);
		assertEquals(true, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 400 
	 * */
	@Test
	public void test0_400Range_valid() {
		int endRange = (int)(400 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__valid(endRange);
		assertEquals(true, validator.validateJSONFile(jsonObject));
	}
}
