package dshukla.fizzBuzzSolution.testSuit;

import static org.junit.Assert.*;

import org.json.simple.JSONObject;
//import org.junit.jupiter.api.BeforeEach;
import org.junit.Before;
import org.junit.Test;
//import org.junit.jupiter.api.Test;

import dshukla.fizzBuzzSolution.FizzBuzzValidator;
import dshukla.fizzBuzzSolution.testSuit.automationTestsUtils.FizzBuzzJSON_Test;

public class AutomatedTest_NegativeCase_FizzBuzzValidationLogicTest {
	FizzBuzzValidator validator; 
	
	@Before
	public void init(){
		validator = new FizzBuzzValidator();
	}
	
	/**
	 * 		Negative cases create by utility function FizzBuzzJSON_Test.createFizzBuzzJSON__invalid
	 * **/
	/**
	 * 	Testing for JSON 1 to 50 
	 * */
	@Test
	public void test0_50Range_valid() {
		int endRange = (int)(50 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__invalid(endRange);
		assertEquals(false, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 100 
	 * */
	@Test
	public void test0_100Range_valid() {
		int endRange = (int)(100 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__invalid(endRange);
		assertEquals(false, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 200 
	 * */
	@Test
	public void test0_200Range_valid() {
		int endRange = (int)(200 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__invalid(endRange);
		assertEquals(false, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 300 
	 * */
	@Test
	public void test0_300Range_valid() {
		int endRange = (int)(300 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__invalid(endRange);
		assertEquals(false, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 400 
	 * */
	@Test
	public void test0_400Range_valid() {
		int endRange = (int)(400 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__invalid(endRange);
		assertEquals(false, validator.validateJSONFile(jsonObject));
	}
	/**
	 * 	Testing for JSON 1 to 500 
	 * */
	@Test
	public void test0_500Range_valid() {
		int endRange = (int)(500 * Math.random());
		
		JSONObject jsonObject = FizzBuzzJSON_Test.createFizzBuzzJSON__invalid(endRange);
		assertEquals(false, validator.validateJSONFile(jsonObject));
	}
}
