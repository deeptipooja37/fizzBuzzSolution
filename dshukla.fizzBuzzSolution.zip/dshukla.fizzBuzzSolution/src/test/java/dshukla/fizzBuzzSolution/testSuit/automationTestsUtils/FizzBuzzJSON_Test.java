package dshukla.fizzBuzzSolution.testSuit.automationTestsUtils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class FizzBuzzJSON_Test {

	
	@SuppressWarnings("unchecked")
	public static JSONObject createFizzBuzzJSON__valid( int endRange) {
		
		JSONArray array = new JSONArray();
		int i=0;
		while (i<=endRange) {
			array.add(fizzBuzzValue(i+1));
			i++;
		}
		JSONObject obj = new JSONObject();
		obj.put("lines", array);
		
		return obj;
		
	}
	@SuppressWarnings("unchecked")
	public static JSONObject createFizzBuzzJSON__invalid(int endRange) {
		JSONArray array = new JSONArray();
		int invalidIndex = (int)(endRange * Math.random())%endRange;
		
		int i=0;
		while (i<=endRange) {
			array.add(fizzBuzzValue(i+1));
			i++;
		}
		array.add(invalidIndex, "FALSE");
		JSONObject obj = new JSONObject();
		obj.put("lines", array);
		
		return obj;
	}
	/**
	 * 		Function to check FIZZZBUZZ value for an int i
	 * */
	public static Object fizzBuzzValue(int i) {
		boolean dividedBy3 = i%3 ==0;
		boolean dividedBy5 = i%5 ==0;
		if(dividedBy3 && dividedBy5)
			return "FIZZBUZZ";
		if(dividedBy3)
			return "FIZZ";
		if(dividedBy5)
			return "BUZZ";
		return i;
	}
	
}
