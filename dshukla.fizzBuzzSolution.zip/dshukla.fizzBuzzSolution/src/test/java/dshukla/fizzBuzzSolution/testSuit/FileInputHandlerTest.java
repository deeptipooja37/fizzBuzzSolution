package dshukla.fizzBuzzSolution.testSuit;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.simple.JSONObject;
import org.junit.Test;
import dshukla.fizzBuzzSolution.FileInputOutputHandler;
import dshukla.fizzBuzzSolution.ParamNotFoundException;

public class FileInputHandlerTest {
	
	/*
	 * 	All invalid file location
	 * 
	 * */
//	@Test(expected = IOException.class)
//	public void testInvalidFileLocation1AsParam() throws ParamNotFoundException {
//		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
//		ioHandler.readJSONFile(new String[]{"C:"});
//	}
//	@Test(expected = IOException.class)
//	public void testInvalidFileLocation2AsParam() throws ParamNotFoundException {
//		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
//		ioHandler.readJSONFile(new String[]{"C:\\deepti\\"});
//	}
	/*
	 * 	Null, empty string or empty array cases
	 * 
	 * */
	@Test(expected = ParamNotFoundException.class)
	public void testNullAsParam() throws ParamNotFoundException {
		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
		ioHandler.isEmpty(null);
	}
	
	@Test(expected = ParamNotFoundException.class)
	public void testEmptyArrayInputArguments() throws ParamNotFoundException {
		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
		ioHandler.isEmpty(new String[]{});
	}
	
	@Test(expected = ParamNotFoundException.class)
	public void testEmptyArray1InputArguments() throws ParamNotFoundException {
		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
		ioHandler.isEmpty(new String[]{null});
	}
	
	@Test(expected = ParamNotFoundException.class)
	public void testEmptyArray12InputArguments() throws ParamNotFoundException {
		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
		ioHandler.isEmpty(new String[]{""});
	}
}
