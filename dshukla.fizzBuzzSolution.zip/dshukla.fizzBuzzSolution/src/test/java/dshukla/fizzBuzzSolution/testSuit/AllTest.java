package dshukla.fizzBuzzSolution.testSuit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AutomatedTest_NegativeCase_FizzBuzzValidationLogicTest.class,
				AutomatedTest_PositiveCase_FizzBuzzValidationLogicTest.class,
				FileOutputHandlerTest.class,
				FileInputHandlerTest.class })
public class AllTest {

}
