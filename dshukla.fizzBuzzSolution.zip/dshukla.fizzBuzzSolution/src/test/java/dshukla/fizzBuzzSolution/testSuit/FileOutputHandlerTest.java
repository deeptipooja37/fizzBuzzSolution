package dshukla.fizzBuzzSolution.testSuit;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import dshukla.fizzBuzzSolution.FileInputOutputHandler;

//@RunWith(JUnitPlatform.class)
public class FileOutputHandlerTest {

//	private PrintStream sysOut;
//    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
// 
//
//	 @Before
//    public void setUpStreams() {
//        sysOut = System.out;
//        System.setOut(new PrintStream(outContent));
//    }
// 
//    @After
//    public void revertStreams() {
//        System.setOut(sysOut);
//    }

	@Test
	public void testWriteResultObjTrueTest() {
//		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
//		ioHandler.writeResultObj(true);
//		assertEquals("The file is a valid FizzBuzz File", outContent.toString());
	}
//	
//	@Test
//	public void testWriteResultObjFalseTest() {
//		FileInputOutputHandler ioHandler = new FileInputOutputHandler();
//		ioHandler.writeResultObj(false);
//		assertEquals("The file is not a valid FizzBuzz File", outContent.toString());
//	}
	
}
